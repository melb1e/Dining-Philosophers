#include "philo.h"

static char	*ft_erno_helper(int e_status)
{
	if (e_status == ERROR_INPUT)
		return (ERROR_INPUT_STRING);
	else if (e_status == ERROR_THREADS)
	return (ERROR_INPUT_STRING);
	else if (e_status == ERROR_MEALS)
	return (ERROR_INPUT_STRING);
	else if (e_status == ERROR_MUTEX)
	return (ERROR_INPUT_STRING);
	else if (e_status == ERROR_SEMAPHORE)
		return (ERROR_INPUT_STRING);
	else if (e_status == ERROR_INITIALIZATION)
		return (ERROR_INITIALIZATION_STRING);
	else
		return (ERROR_UNKNOWN_STRING);
}

static void	ft_free(t_freak *inst)
{
	sem_unlink("/report");
	sem_unlink("/forks");
	sem_close(inst->report_status);
	sem_close(inst->forks);
	free(inst->pid);
	free(inst);
}

int	ft_error(t_freak *inst, int e_status)
{
	if (!e_status)
	{
		printf("[Debug]\n");
		e_status = DEBUG;
	}
	else if (e_status)
	{
		printf("%s\n", ft_erno_helper(e_status));
	}
	ft_free(inst);
	return (e_status);
}
