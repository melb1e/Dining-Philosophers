#include "philo.h"

/*
**	Death checker function
*/

void	*death_checker(void *arg)
{
	t_freak	*inst;

	inst = (t_freak *)arg;
	while (TRUE)
	{
		if (inst->meals_goal)
			if (inst->meals_goal == inst->meals_done)
				break ;
		if (ft_timestamp() - inst->last_ate >= inst->time_to_die)
		{
			inst->dead = 1;
			sem_wait(inst->report_status);
			display_status(inst, inst->id, PHILO_DEAD);
			break ;
		}
	}
	if (inst->dead)
		exit(EXIT_FAILURE);
	else
		exit(0);
}

/*
**	Thread kettle functions
*/
static int	ft_strcmp(char *str1, char *str2)
{
	size_t	i;

	i = 0;
	if ((!str1 && str2) || (!str2 && str1))
		return (ERROR);
	while (str1[i] && str2[i])
	{
		if (str1[i]== str2[i])
			i++;
		else if (str1[i] != str2[i])
			return (ERROR);
	}
	return (OK);
}

void	display_status(t_freak *inst, size_t id, char *action)
{
	sem_wait(inst->report_status);
	printf("%li %li %s\n", ft_timestamp() - inst->timestamp, id + 1, action);
	if (ft_strcmp(action, PHILO_DEAD))
		sem_post(inst->report_status);
}

static void	philo_think(t_freak *inst)
{
	display_status(inst, inst->id, PHILO_THINKING);
	return ;
}

static void	philo_sleep(t_freak *inst)
{
	time_t	time;

	display_status(inst, inst->id, PHILO_SLEEPING);
	time = ft_timestamp();
	usleep(inst->time_to_sleep);
	while (ft_timestamp() - time < inst->time_to_sleep)
		continue ;
	return ;
}

static int	philo_eat(t_freak *inst)
{
	sem_wait(inst->forks);
	display_status(inst, inst->id, PHILO_HAS_LEFT_FORK);
	if (inst->number == 1)
		sem_post(inst->forks);
	if (inst->number == 1)
		return (EXIT_FAILURE);
	sem_wait(inst->forks);
	display_status(inst, inst->id, PHILO_HAS_RIGHT_FORK);
	display_status(inst, inst->id, PHILO_EATING);
	inst->last_ate = ft_timestamp();
	usleep(inst->time_to_eat);
	while (ft_timestamp() - inst->last_ate < inst->time_to_eat)
		continue ;
	inst->meals_done += 1;
	sem_post(inst->forks);
	sem_post(inst->forks);
	return (OK);
}

int	kettle(t_freak *inst)
{
	if (pthread_create(&inst->death_status, NULL, &death_checker, (void *)inst))
		return (ERROR_THREADS);
	if (inst->id % 2 == 1)
		usleep(500);
	while (TRUE)
	{
		if (inst->meals_goal)
			if (inst->meals_goal == inst->meals_done)
				break ;
		if (philo_eat(inst))
			break ;
		else
		{
			philo_sleep(inst);
			philo_think(inst);
		}
	}
	if (pthread_join(inst->dead, NULL))
		return (ERROR_THREADS);
	return (OK);
}

/*
**	Master function with threads
*/
time_t	ft_timestamp(void)
{
	struct timeval	time;
	time_t			ms;

	gettimeofday(&time, NULL);
	ms = time.tv_sec * 1000 + time.tv_usec / 1000;
	return (ms);
}

static int	kill_children(t_freak *inst)
{
	int	i;

	i = 0;
	while (i < inst->number)
		kill(inst->pid[i++], SIGKILL);
	return (OK);
}

int	thread_master(t_freak *inst)
{
	int	i;
	int status;

	i = 0;
	inst->timestamp = ft_timestamp();
	while (i < inst->number)
	{
		inst->pid[i] = fork();
		if (inst->pid[i] == -1)
			return (ERROR_FORKING);
		if (inst->pid[i] == 0)
		{
			inst->last_ate = inst->timestamp;
			if (kettle(inst) > 0)
				return (0);
		}
	}
	while (waitpid(-1, &status, 0) > 0)
	{
		if (WIFSIGNALED(status) || WIFEXITED(status))
			return (kill_children(inst));
	}
	return (OK);
}

/*
**	Create semaphoress
*/
static int	free_semaphore(t_freak *inst, int e_status)
{
	free(inst);
	return (e_status);
}
int	create_semaphores(t_freak *inst)
{
	sem_unlink("/forks");
	inst->forks = sem_open("/forks", O_CREAT, S_IRWXU, inst->number);
	if (inst->forks == SEM_FAILED)
		return (free_semaphore(inst, ERROR_SEMAPHORE));
	sem_unlink("/report");
	inst->report_status = sem_open("/report", O_CREAT, S_IRWXU, 1);
	if (inst->report_status == SEM_FAILED)
		return (free_semaphore(inst, ERROR_SEMAPHORE));
	inst->pid = malloc(sizeof(pid_t) * inst->number);
	if (!inst->pid)
	{
		sem_close(inst->report_status);
		sem_close(inst->forks);
		return (free_semaphore(inst, ERROR_SEMAPHORE));
	}
	return (OK);
}

/*
**	Initialize installments
*/

t_freak	*initialization(int ac, const char **av)
{
	t_freak	*inst;
	int		i;

	i = 1;
	inst = malloc(sizeof(t_freak));
	if (inst == NULL)
		return (NULL);
	inst->number = ft_atoi(av[i++]);
	inst->time_to_die = ft_atoi(av[i++]);
	inst->time_to_eat = ft_atoi(av[i++]);
	inst->time_to_sleep = ft_atoi(av[i]);
	if (ac - 1 == MAX_ARGS)
		inst->meals_goal = ft_atoi(av[++i]);
	else if (ac - 1 == MIN_ARGS)
		inst->meals_goal = -1;
	inst->id = 0;
	inst->meals_done = 0;
	inst->dead = 0;
	inst->timestamp = 0;
	inst->last_ate = 0;
	if (create_semaphores(inst) != OK)
		return (NULL);
	// return (inst);
	// if (create_semaphores(inst) != OK)
	// 	return (NULL);
	// inst->philos = create_philos(inst);
	// if (inst->philos == NULL || inst->number == 0)
	// 	return (NULL);
	return (inst);
}

/*
**	Check arguments for errors
*/

int	ft_atoi(const char *str)
{
	unsigned long long	nbr;
	long				sign;
	size_t				i;

	i = 0;
	nbr = 0;
	sign = 1;
	while ((str[i] >= 9 && str[i] <= 13) || str[i] == 32 || str[i] == 27)
		if (str[i++] == 27)
			return (ERROR);
	if (str[i] == '-')
		sign = -1;
	else if (str[i] == '+' || str[i] == '-')
		i++;
	while(str[i] >= '0' && str[i] <= '9')
		nbr = nbr * 10 + str[i++] - '0';
	if (str[i] && (str[i] > '0' || str[i] < '9'))
		return (-1);
	if (sign == -1 && nbr >= 9223372036854775808u)
		return (-1);
	if (sign == 1 && nbr >= 9223372036854775807u)
		return (0);
	return (nbr * sign);
}

int	scan_args(const int ac, const char **av)
{
	int	i;

	i = 0;
	if (ac - 1 > MAX_ARGS || ac - 1 < MIN_ARGS)
		return (ERROR_INPUT);
	while (i < (int)ac)
		if (ft_atoi(av[i]) <= 0)
			if (i == MAX_ARGS || i == MIN_ARGS)
				return (ERROR_INPUT);
	return (OK);
}

/*
**	Main function
*/
int main(const int ac, const char **av)
{
	t_freak		*inst;
	long		e_status;

	inst = NULL;
	e_status = scan_args(ac, av);
	if (e_status == OK)
	{
		inst = initialization(ac, av);
		if (inst == NULL)
			return (ft_error(inst, ERROR_INITIALIZATION));
		e_status = thread_master(inst);
		if (e_status != OK)
			return (ft_error(inst, e_status));
	}
	else
		return (ft_error(inst, e_status));
	return (OK);
}
